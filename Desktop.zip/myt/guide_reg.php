<? session_start();?>
<? $id = $_SESSION['ss_id'];
    include "./config/dbcon.php";
	mysql_query("set names utf8");
	
	$sql = "update member_info set m_role=2 where m_id = '$id'";
	$result = mysql_query($sql);
	if(!$result)
	{
		echo("<script>
					alert('등록이 실패하였습니다. 잠시 후 다시 시도해 주세요.');
					history.back();
			</script>");
	}
	else
		echo("<script>
					
					parent.location.replace('mainpage.php');
			</script>");


?>


