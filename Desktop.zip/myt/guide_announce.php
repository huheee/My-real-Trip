<? session_start();?>
<!doctype html>

<html>
<head>

<style type="text/css">
div.step {
	width:400px	;
	height:300px ;
	float:left;
	margin:50px;
	}
div.main {
	width:1000px;
	height:700px auto;
	
	margin:50px;}

</style>
<meta charset="utf-8">
<title>무제 문서</title>
</head>

<body>
<div class="main">
<center><p><h3>마이리얼트립 가이드 등록하기</h3></p>
<div class="step">
<img src="guide_step1.png" alt="step 1">
<p> 첫번째, 가이드로 등록해 주세요.
<br> 먼저 사이트에 가이드로 등록해 주시고 마이리얼트립의 도움을 받아 자신이 구상한 투어 상품을 직접 올려주세요.
</p>
</div>

<div class="step">
<img src="guide_step2.png" alt="step 2">
<p> 두번째, 여행자의 예약을 받아보세요.
<br />등록한 여행 내용 그대로 여행자에게 예약을 받거나, 여행자와 협의 후 맞춤 여행을 진행할 수도 있습니다.
<br />편리한 마이리얼트립 예약 시스템을 활용해 보세요.
</p>
</div>

<div class="step">
<img src="guide_step3.png" alt="step 3">
<p> 세번째, 가이드 여행을 진행하세요.
<br />여행을 진행하며 현지에 대한 지식과 노하우를 공유하고 이를 통해 여행자에게 특별한 여행 경험을 선사하세요.
</p>
</div>

<div class="step">
<img src="guide_step4.png" alt="step 4">
<p> 네번째, 마케팅을 통하여 더 큰 수익을 만들어 보세요.
<br />여행 후기에 대한 답변을 작성하는 등 마이리얼트립이 제안하는 활동에 적극 참여하여 여행 예약율을 높여 보세요.
</p>
</div>

<a href="guide_reg.php"><button>가이드 등록하기 </button></a>             
<a href="mainpage.php"><button>돌아가기</button></a>

</center>
</div>




</body>
</html>
