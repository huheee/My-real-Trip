<? session_start();
	include "./config/dbcon.php";
	mysql_query("set names utf8");
	
	
	$sql = "select * from notice order by n_num asc limit 5 ";
	
	$result = mysql_query($sql);
	
	$notice = array();
	
	$no = 0;
	while ($row=mysql_fetch_object($result)) {
		$notice[$no] = $row->n_num.",";
		$notice[$no] .= $row->n_name.",";
		$notice[$no] .= $row->n_notice."/";
		
		echo $notice[$no];
		$no++;
	}
	
	
	
?>