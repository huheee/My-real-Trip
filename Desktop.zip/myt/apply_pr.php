<? session_start();
	include "./config/dbcon.php";
	mysql_query("set names utf8");
	$id = $_SESSION["ss_id"];
	$code = $_GET["code"];
	$sql = "select count(m_id) as same from apply where m_id = '$id' and pr_code = $code limit 1;";
	
	$result = mysql_query($sql);
	
	if($result)
	{
		$row = mysql_fetch_object($result);
		
		$no = $row->same;
		
		
			if($no > 0)
			{
				echo("<script>
					alert('이미 신청하였습니다.');
					history.back();
					</script>");
			}
			
			else
			{
				$sql = "insert into apply(m_id, pr_code) values ('$id', $code);";
				
				$result = mysql_query($sql);
				
				if($result)
				{
					echo("<script>
					alert('신청하였습니다.');
					parent.location.replace('mainpage.php');
					</script>");
				}
				else
				{
					echo("<script>
					alert('데이터 베이스 insert 오류.');
					history.back();
					</script>");
				}
			}
		
		
		
	}
	
	else
				{
					echo("<script>
					alert('데이터 베이스 select 오류.');
					history.back();
					</script>");
				}
	
	

?>


