<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>무제 문서</title>
</head>

<body>


<div style="float:left; width:100%; height:400px  position:relative">
	<img src="main1.jpg" id=mainImage alt="YsjImage" style="width:100%;height:400px;">
    <div style="position:absolute; top:50%;">
    	<h3 style="color:#FFFFFF">     쉽고 빠르게 준비하는 자유여행</h3>
    </div>
</div>





</body>
</html>
