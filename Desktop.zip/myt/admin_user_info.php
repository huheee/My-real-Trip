<? session_start();
	include "./config/dbcon.php";
	mysql_query("set names utf8");
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>무제 문서</title>
</head>

<body>
	<center>
    <form action="" >
    <table border="1">
            	<tr>
                	<td>유저 ID</td>
                    <td>유저 이름</td>
                    <td>비밀번호</td>
                    <td>사용자 등급</td>
                    <td>유저 정보 삭제</td>
                </tr>
<?

	$sql = "select * from member_info order by m_role";
	$result = mysql_query($sql);
	
	while($rows = mysql_fetch_object($result)){
		$id = $rows->m_id;
		$name = $rows->m_name;
		$pass = $rows->m_pass;
		$role = $rows->m_role;
		if($role == 2)
		{
			$role = "가이드";
		}
		else if($role == 3)
		{
			$role = "관리자";
		}
		else
		{	
			$role = "유저";
		}
		
		
?>

	<tr>
    	<td> <?=$id?></td>
        <td> <?=$name?></td>
        <td> <?=$pass?></td>
        <td> <?=$role?></td>
                            
		<td><center><button type="button" onclick="location.href='admin_del.php?id=<?echo $id;?>'">삭제하기</button></center></td>
						</tr>

<?
	}
?>
 		
        </table>
        </form>
        </center>
              

</body>

</html>
