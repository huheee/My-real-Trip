<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>구글맵(Google Maps JavaScript API v3) 적용, 위치 표시와 말풍선 띄우기</title>
</head>

<body>

<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=ture_or_false"></script>
<script>
function initialize() {

	var geocoder = new google.maps.Geocoder();

	var addr="주소";

	var lat="";
	var lng="";

	geocoder.geocode({'address':addr},

		function(results, status){

			if(results!=""){

				var location=results[0].geometry.location;

				lat=location.lat();
				lng=location.lng();	
				
				var latlng = new google.maps.LatLng(lat , lng);
				var myOptions = {
					zoom: 16,
					center: latlng,
					mapTypeControl: true,
					mapTypeId: google.maps.MapTypeId.ROADMAP
				};
				var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);  

			}
			else $("#map_canvas").html("위도와 경도를 찾을 수 없습니다.");
		}
	)
}

$(function(){initialize()})
</script>
<style>
#map_canvas {width:740px;height:400px;}
</style>
<div id="map_canvas"></div>

</body>
</html>
