<? session_start();
	include "./config/dbcon.php";
	mysql_query("set names utf8");
	
	
	$sql = "select count(m_id) as num from member_info";
	$result = mysql_query($sql);
	
	
	$pre = array();
	
	$row=mysql_fetch_object($result);
	$pre[0] = $row->num;
	$pre[0] .= ",";
	echo $pre[0];
	
	
	
	$sql = "select count(m_id) as num from member_info where m_role = 2";
	$result = mysql_query($sql);
	
	
	$pre = array();
	
	$row=mysql_fetch_object($result);
	$pre[1] = $row->num;
	$pre[1] .= ",";
	echo $pre[1];
	
	
	
	$sql = "select count(pr_code) as pr_num from program";
	
	
	
	$result = mysql_query($sql);
	
	$row=mysql_fetch_object($result);
	$pre[2] = $row->pr_num;
	
	echo $pre[2];
	
	

	
	
	
	
?>
