<? session_start();
	include "./config/dbcon.php";
	mysql_query("set names utf8");
	
	$id = $_GET['id'];
	
	$sql = "delete from member_info where m_id = '$id'";
	$result = mysql_query($sql);
	
	if($result)
	{
		
		echo("<script>
				alert('$id'+' 삭제 성공');
				location.href='admin_user_info.php';
		</script>");
	}

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
