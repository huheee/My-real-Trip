<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
<title>무제 문서</title>
</head>

<body>
<p id="user_num"></p>
<p id="program_num"></p>

<script>
$(document).ready(function() {
     
 
setInterval("ck_users()", 1000); 

});

function ck_users(){
	
	
	
	
	$.post("ck_stat.php",{},function (responseTxt, statusTxt, xhr){
	
		var data = responseTxt.split(",");
		var cl_us = document.getElementById('user_num');
		cl_us.innerHTML="";
		var cl_pr = document.getElementById('program_num');
		cl_pr.innerHTML="";
		
		
		cl_us.innerHTML = "전체 유저 수 : "+data[0]+" 명<p>";
		cl_us.innerHTML += "가이드 수 : "+data[1]+" 명";
		cl_pr.innerHTML = "전체 프로그램 수 : "+data[2]+" 개";
		
		
	});
}



</script>

</body>
</html>
