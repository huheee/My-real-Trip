<? session_start();
	include "./config/dbcon.php";
	mysql_query("set names utf8");
	$role = $_SESSION['ss_role'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>무제 문서</title>
</head>

<body>
<center>
    <form action="">
    <table border="1">
            	<tr>
                	<th>프로그램 코드</th>
                    <th>프로그램 이름</th>
                    <th>지역</th>
                	<th>카테고리</th>
                    <th>가격</th>
                    <th>여행기간</th>
                    <th>상세보기</th>
                    <th>삭제하기</th>
                </tr>
                
<?
	$sql = "select * from program";
	$result = mysql_query($sql);
	while($rows = mysql_fetch_object($result)){
					$code = $rows->pr_code;
					$name = $rows->pr_name;
					$region = $rows->pr_region;
					$country = $rows->pr_country;
					$city = $rows->pr_city;
					$categorygroup = $rows->pr_categorygroup;
					$price = $rows->pr_price;
					$durationtype = $rows->pr_durationtype;
					
					
					?>
                    	<tr>
                        	<td> <?=$code?></td>
                            <td> <?=$name?></td>
                            <td> <?=$region."  ".$country."  ".$city ?></td>
                            <td> <?=$categorygroup?></td>
                            <td> <?=$price?></td>
                            <td> <?=$durationtype?></td>
                            <td><button type="button" onclick="location.href='detail.php?code=<?echo $code;?>'">선택</button></td>
                            <td><button type="button" onclick="location.href='admin_del_program.php?code=<?echo $code;?>'">삭제하기</button></td>
						</tr>
					<?
		
				}

           ?>
           	  
              </table>
              </form>
              </center>




</body>
</html>
