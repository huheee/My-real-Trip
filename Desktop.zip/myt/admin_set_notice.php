<? session_start();
	include "./config/dbcon.php";
	mysql_query("set names utf8");
	
	$n_name = $_POST['n_name'];
	
	if($n_name != "")
	{
		$n_notice = $_POST['n_notice'];
		
		$sql = "select count(*) as num from notice";
		$result = mysql_query($sql);
		
		$row=mysql_fetch_object($result);
		$n_num = $row->num;
		
		echo $n_num;
		
		
		$sql = "insert into notice (n_num, n_name, n_notice) values ($n_num,'$n_name', '$n_notice')";
		$result = mysql_query($sql);
		if($result)
		{
			echo("<script>
					alert('공지사항 입력 성공');
			
			</script>");
		}
		else
		{
			echo("<script>
					alert('공지사항 입력 실패');
			
			</script>");
			}
	}
	
	
	
	
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>무제 문서</title>
</head>

<body>
<form action="" method="post">
<table border="1">
<tr>
	<th>공지사항 제목</th>
    <td><input type="text" id="n_name" name="n_name" /></td>
</tr>
<tr>
<th>공지사항 내용</th><td><textarea name="n_notice" id="n_notice"></textarea></td>	
</tr>

</table>

<input type="submit" name="submit" value="공지사항 등록"/>
<input type="button" onclick="back();" value="돌아가기"/>
</form>


</body>
<script>
function back(){
	location.href="ck_stat.php";
	
	}
</script>




</html>
