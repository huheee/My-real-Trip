<? session_start();
	
	include "./config/dbcon.php";
	mysql_query("set names utf8");
	
	
	
	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link rel="stylesheet" type="text/css" href="mystyle.css">
 <script type="text/javascript" src="script.js"></script>

	
<title>메인 페이지</title>
</head>

<body>

<div style="background-color:#25A8C9" class ="up_bar" >

<h1 class="head_text" > My Real Trip</h1>

</div>

<div style="width:20%; float:left">
<form action="input_p.php" method="post" name="main" id="main">
<table width="100%" border="0" class="log_on">
	<tr>
    	<td width="306" colspan="2"><center>관리자 님 환영합니다.</center></td>
    </tr>
    <tr>
    <td><center><input type="button" value="유저 관리" onclick="changeIframeUrl('admin_user_info.php');"/><input type="button" value="공지 사항" onclick="changeIframeUrl('admin_set_notice.php');"/></center></td>
    </tr>
    
    <tr>
    
    	<td rowspan="2"> 
        <center>
        <input type="button" value="상품 관리" id="pr_input" name="pr_input" onclick="changeIframeUrl('admin_program.php');"/><input type="button" value="로그 아웃" onclick="logout();"/>
        </center>
		</td>
        
        
	</tr>
    
    
    

</table>
	
   
</form>
</div>



<iframe src="admin_stat.php" width="79%" height="700px" style="float:left;" name="main_frame" id="main_frame"></iframe>





</body>



</html>
