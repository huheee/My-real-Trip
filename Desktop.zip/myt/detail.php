<? session_start(); 
	$name = $_SESSION["ss_name"];
	$role = $_SESSION['ss_role'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link rel="stylesheet" type="text/css" href="mystyle.css">
<title>무제 문서</title>

</head>



<body>
<form action="">
<input type="hidden" id="u_role" name="u_role" value="<?=$role?>"/>
</form>
<?

	include "./config/dbcon.php";
	mysql_query("set names utf8");
	
	
	$code = intval($_GET['code']);
	$filename = "file.php";
	include_once($filename);
?>

<script type="text/javascript" src="script.js"></script>
<script>
function back(){
		var role = document.getElementById("u_role").value;
		if(role == 3)
		{
			location.href="admin_program.php";
		}
		else
		{
		 location.href="searchpage.php";
		}
	}
</script>
	




<br /><br /><center>

<br /><button onclick="back();">종료</button></center>

</body>
</html>
