<? session_start();
	
	
	include "./config/dbcon.php";
	mysql_query("set names utf8");
	
	$id = $_SESSION["ss_id"];
	
	$sql = "select * from member_info where m_id = '$id'";
	$result = mysql_query($sql);
	
	$rows = mysql_fetch_object($result);
	
	$name = $rows->m_name;
	$pass = $rows->m_pass;
	$role = $rows->m_role;
	
	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="mystyle.css">



<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>무제 문서</title>
</head>


<body>

<script>

function pass_ck_visb(){
    document.getElementById('pass_check').style.display="";
	document.getElementById('pass_chag').style.display="";
	document.getElementById('pass').value="";
	
	
}

function pass_change(){
	
	var pass = document.getElementById('pass');
	
	var pass_ck = document.getElementById('pass_ck');
	
	
	if(pass.value != pass_ck.value)
	{
		alert("입력된 비밀번호가 서로 다릅니다!");
		return false;
	}
	else
	{
		document.member_detail.action = "pass_changing.php";
		document.member_detail.submit();
		 
	}
}

function role_ck(){
	
	var check = document.getElementById('role_val');
	
	if( check.value == 0)
	{
		document.write("관리자");
	}
	else if(check.value == 2)
	{	
		document.write("가이드");
	}
	else
	{
		document.write("일반회원");
	}
	
	
}




</script>






<form action="mainpage.php" method="post" name="member_detail">
<center>
	<h3> 회원 정보 </h3>
	<table border="1" width=40% height="50%">
    	<tr>
        	<th width="150"> 아이디
            </th>
            <td width="280"> <?= $id ?> </td>
        </tr>
        <tr>
        	<th> 이름
            </th>
            <td> <?= $name ?> </td>
        </tr>
         <tr>
        	<th> 회원 상태
            </th>
            <td>
            	<input type="hidden" value="<?=$role?>" id="role_val" name="role_val" />
                
            	<script>role_ck();</script>
            </td>
        </tr>
        <tr>
        	<th> 비밀번호
            </th>
            <td>
            <input id="pass" type="password" name="pass" value="<?=$pass?>"/>
            
            </td>
        </tr>
        <tr id="pass_check" style="display:none">
        	<th> 비밀번호 확인
            </th>
       		 <td> <input type="password" name="pass_ck" id="pass_ck"/>
            </td>
        </tr>
       
    </table>
    <br />
    
    <a href="my_pr_apply.php"><input type="button" value="내가 신청한 프로그램"/></a>
    <br />
    
    <input type="button" value="비밀번호 변경" onclick="pass_ck_visb();"/>
    
 	<button type="button" id="pass_chag" style="display:none"   onclick="pass_change();">비밀번호 변경 확인</button>
    <a href="guide_announce.php"><input type="button" value="가이드 등록"/></a>
    <input type="button" value="돌아가기" onclick="back();"/>

</center>
</form>
<script>
function back(){
		parent.location.replace('mainpage.php');
	
	}

</script>


</body>
</html>
